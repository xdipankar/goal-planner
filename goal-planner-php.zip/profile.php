<?php include"dm/app-header.php" ?>
<title>GP Goal Planner|<?php echo $dm_name ?></title>
<!-- ..........Start........ -->

<!-- ..........End........ -->
<?php include("dm/app-footer.php") ?>