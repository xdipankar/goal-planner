<?php 
	$app_name = "GP - Goal Planner" ;
	$app_url = "https://gp.munka.in" ;
	$app_version = "2.0"; 
	$update_date = "04-09-2022";
	$initial_release = "20-08-2020";
?>