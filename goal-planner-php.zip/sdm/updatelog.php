
	<!-- Form modal -->
	<div id="updatelog" class="modal" tabindex="-1" role="dialog">
		<div class="modal-dialog modal-dialog-scrollable" role="document">
			<div class="modal-content">
				<div class="modal-header gradient-ibiza-sunset">
					<!-- //<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button> -->
					

					<h4 class="modal-title text-white"><a data-dismiss="modal" data-toggle="modal" href="#changelog"><i class="ft-corner-up-left text-white"></i></a> Update Log</h4> 
					<button type="button btn-warning" class="close" data-dismiss="modal" aria-hidden="true"> <span id="" class="ft-x text-white"> </span> </button>
				</div>
					<div class="modal-body with-padding">
						<h5 class="text-success">Version : 2.0 (05-09-2022)</h5>
						<ul>
							<li>Added Task System.</li>
							<li>Categorise your Task with multiple category.</li>
							<li>Using of 4 Quadrant Method in Task system.</li>
							<li>Removed Deposit Entry.</li>
							<li>Add Balance with Update date in Account.</li>
	
						</ul>
						<h5 class="text-success">Version : 1.0 (20-08-2020)</h5>
						<ul>
							<li>Initial Release.</li>
	
						</ul>
						
						<!-- <h5 class="text-success"><u>Update : 4.0 (16-08-2020)</u></h5>
						<ul>
							<li>Added Changelog and update detail view feature on footer.</li>
							<li>Added Updated Application Version Number on footer.</li>
							<li>Added Preloader on Page Loading.</li>
							<li>Redesign Login Page with minor modification and include Animatation.</li>
							<li>Change Date Type in Expense table from varchar to Date in Database.</li>
							<li>Users : Added Custom Input Date on User Expense Entry Page.</li>
							<li>Users : Added Red Background to wallet Balance if Negetive Amount in User's Wallet.</li>
							<li>Users : Added Date after Title in Today's Expense.</li>
							<li>Users : Restrict for Future Date Selection in User Expense Entry Page.</li>
							<li>Users : Restrict for Future Date selection in Start Date & End Date in Expense View Page.</li>
							<li>Users : Restrict for Future Date selection in Start Date & End Date in Advance View Page.</li>
							<li>Users : Update Design of User Add Expense Form Modal.</li>
							<li>Users : Update Submit button to Disabled if Required Fields are empty in Add Expense Page.</li>
							<li>Users : Hide Submit Button After One Click in User Add Expense Page.</li>
							
							<li>Admin : Restrict to Edit email id of User in User List.</li>
							<li>Admin : Project Name Edit Restriction on Project Dashboard.</li>

						</ul> -->

					</div>
			</div>
		</div>
	</div>
<!-- /form modal -->