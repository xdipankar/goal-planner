	<!-- Form modal -->
	<div id="changelog" class="modal hide"  data-replace="true" tabindex="-1" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header gradient-ibiza-sunset">
					<h4 class="modal-title text-white"><i class="icon-paragraph-justify2"></i>Change Log</h4>
					<button type="button btn-warning" class="close" data-dismiss="modal" aria-hidden="true"><span id="" class="ft-x text-white"> </span> </button>
				</div>
					<div class="modal-body with-padding">
						<h5 class="text-success">Version : 2.0 (05-09-2022)</h5>
						<ul>
							<li>Added Task System.</li>
							<li>Categorise your Task with multiple category.</li>
							<li>Using of 4 Quadrant Method in Task system.</li>
							<li>Removed Deposit Entry.</li>
							<li>Add Balance with Update date in Account.</li>
							
	
						</ul>
						<div align="center">
							<a data-dismiss="modal" data-toggle="modal" class="btn bg-light-warning btn-sm" href="#updatelog"><i class="fa fa-eye nav-icon"></i> View All Update Log</a>
						</div>

					</div>
			</div>
		</div>
	</div>
<!-- /form modal -->