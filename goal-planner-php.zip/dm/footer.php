</div>
        </div>
        <!-- END : End Main Content-->
        <?php include 'sdm/changelog.php' ?>
        <?php include 'sdm/updatelog.php' ?>
        <!-- BEGIN : Footer-->
        <footer class="footer undefined">
       
          <p class="clearfix  m-0"><span>Copyright  &copy; </span><a href="<?php echo $app_url ?>" id="munka" target="_blank"><?php echo $app_name ?></a><span> 2020,</span><span class="d-none d-sm-inline-block">All rights reserved.</span><button type="button" class="btn btn-sm btn-outline-default" data-toggle="modal" data-target="#changelog"><i class="fa fa-eye nav-icon text-danger"></i></button> </p>
        </footer>
        <!-- End : Footer--><!-- Scroll to top button -->
        <button class="btn btn-primary scroll-top" type="button"><i class="ft-arrow-up"></i></button>

      </div>
    </div>
    <!-- ////////////////////////////////////////////////////////////////////////////-->
    
<!-- Theme customizer Ends-->
    <!-- 
    <div class="buy-now">
     
<a href="#" target="_blank" class="btn btn-danger">Donate</a>
    </div> -->
    <script type="text/javascript">
     (function () {
         var options = {
             facebook: "107618990843549", // Facebook page ID
            email: "contact@munka.in", // Email
            whatsapp: "+918984905005", // WhatsApp number         
            sms: "+918984905005", // Sms phone number
            instagram: "munkaofficial", // Instagram usernam          
            call_to_action: "Message us", // Call to action
             button_color: "#FF6550", // Color of button
             position: "left", // Position may be 'right' or 'left'
             order: "whatsapp,facebook,instagram,sms", // Order of buttons
         };
         var proto = document.location.protocol, host = "getbutton.io", url = proto + "//static." + host;
         var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
         s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
         var x = document.getElementsByTagName('script')[1]; x.parentNode.insertBefore(s, x);
     })();
</script>

    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>
    <!-- BEGIN VENDOR JS-->
    <script src="vendors/js/vendors.min.js"></script>
    <script src="vendors/js/switchery.min.js"></script>
    <!-- BEGIN VENDOR JS-->
    <!-- BEGIN PAGE VENDOR JS-->
    <script src="vendors/js/chartist.min.js"></script>
    <script src="vendors/js/apexcharts.min.js"></script>
    <script src="js/charts-apex.min.js"></script>
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN APEX JS-->
    <script src="js/core/app-menu.min.js"></script>
    <script src="js/core/app.min.js"></script>
    <script src="js/notification-sidebar.min.js"></script>
    <script src="js/customizer.min.js"></script>
    <script src="js/scroll-top.min.js"></script>
    <!-- END APEX JS-->
    <!-- BEGIN PAGE LEVEL JS-->
    <script src="js/dashboard2.min.js"></script>

    <!-- END PAGE LEVEL JS-->
    <!-- BEGIN: Custom CSS-->
    <script src="js/scripts.js"></script>
    <script src="js/components-modal.min.js"></script>
    <script src="js/ex-component-sweet-alerts.min.js"></script>
     <script src="vendors/js/sweetalert2.all.min.js"></script>
    <!-- END: Custom CSS-->
  </body>
  <!-- END : Body-->
</html>