<?php
	
	$DBhost = "localhost";
	$DBuser = "munkasdm_gp";
	$DBpass = "munkasdm_gp123";
	$DBname = "munkasdm_gp";
	
	try{
		
		$DBcon = new PDO("mysql:host=$DBhost;dbname=$DBname",$DBuser,$DBpass);
		$DBcon->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		
	}catch(PDOException $ex){
		
		die($ex->getMessage());
	}
	?>