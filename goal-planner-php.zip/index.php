<?php
/*
Author: Dipankar Mohanta
Website: http://www.dipankarmohanta.com/
*/

require("inc/auth.php"); //include auth.php file on all secure pages 
?>
<?php

  echo '<script type="text/javascript">window.location.href = "home.php";</script>'; 

?>